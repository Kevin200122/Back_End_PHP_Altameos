<?php
include('config.php');
include('../PHP/Nav_Accueil.php')
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../styles/A_Propos_De_Cet_Artiste.css">
</head>
<body>

</body>
</html>