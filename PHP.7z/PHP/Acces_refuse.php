<?php
include('config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Accès interdit </title><h1>⛔</h1>
<!-- Mettez ici les liens vers vos fichiers CSS et autres ressources si nécessaire -->
</head>
<body>
<h1>Accès interdit</h1>
<p>Vous n'avez pas le droit d'accéder à cette page.</p>
<p>Veuillez retourner sur cette page <a href="../PHP/Accueil2.php">Accueil</a></p>
</body>
</html>
