<?php
include('config.php');
include('../PHP/Nav_Accueil.php');
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../styles/Actualite.css">
</head>
<body>
<container class="Navbar">
<h1>ACTUALITÉS</h1>
</container>
<table>
<tr>
<td>NUIT DE SONGE - NOUVEAU MORCEAU DISPONIBLE ►</td>
</tr>
<tr>
<td>TITAN BEARD SUR BANDCAMP → </td>
</tr>
<tr>
<td>TITAN SE DÉCOUVRE DURANT L'ÉMISSION EDUCAP QUIZ 2021 ►</td>
</tr>
<tr>
<td>TITAN FM EST LANCÉ, DISPONIBLE À L'ÉCOUTE ►</td>
</tr>
<tr>
<td>TITAN FM A BESOIN DE VOUS ►</td>
</tr>
<tr>
<td>LES CONFESSIONS DE TRISTAN ►</td>
</tr>
<tr>
<td>TRISTAN OU LA MUSIQUE COMME PASSION ►</td>
</tr>
<tr>
<td>À ÉVREUX, TRISTAN BÉARD RAPPE SON HANDICAP MAIS AUSSI<br><br>
L'AMOUR ET L'AMITIÉ ►</td>
</tr>
</table>

</body>
</html>
<?php
include("../PHP/footer.php")
?>