<?php
include('config.php');
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../styles/Footer.css">
</head>
<body>
<footer>
<div class="container"><br>
<p class="Para" id="Le_Para">POSITIVE HANDICAP</p>
<p class="Para2" id="Le_Para2">DÉPASSER LE HANDICAP : LA MUSIQUE COMME THÉRAPIE,COMME COMBAT,<br />
COMME EXPRESSION,COMME IMAGINATION, COMME LIEN SOCIAL !</p><br /> <br />
<p class="Mini_Para" id="Le_Mini_Para">TOUTES LES OEUVRES PRÉSENTÉS SUR LE SITE SONT LA PROPRIÉTÉ DE M.TRISTAN BEARD.<br />
TOUTE L'UTILISATION DEVRA FAIRE L'OBJET D4UNE DEMANDE D'AUTORISATION VIA LE FORMULAIRE DE CONTACT.<br />
TOUTE UTILISATION ILLICITE POURRAIT FAIRE L4OBJET DE POURSUITES.</p>
<img src="../Image/titan-fm-logo copie 1 (1).png" id="Logo" alt="un-logo">
<a class="navbar-brand" href="#">
</a>

</div>
</nav>
</footer>
</body>
</html>